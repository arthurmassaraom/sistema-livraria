document.addEventListener('DOMContentLoaded', () => {
  const form = document.querySelector('#cep-form');
  if (!form) return;
  const input = document.querySelector('#cep');
  const feedback = document.querySelector('#cep-feedback');
  const result = document.querySelector('#cep-result');
  const container = document.querySelector('#regional-results');
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const cep = input.value.replace(/\D/g, '');
    if (cep.length !== 8) {
      feedback.textContent = 'Digite um CEP válido com 8 números.';
      return;
    }
    feedback.textContent = 'Consultando endereço e bibliotecas próximas…';
    try {
      const response = await fetch(`/api/cep/${cep}`, {
        headers: {
          'Accept': 'application/json'
        }
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.erro || 'Consulta indisponível');
      const address = data.endereco;
      result.hidden = false;
      result.className = 'region-message';
      result.textContent = `CEP ${address.cep || cep}: ${address.logradouro || 'logradouro não informado'} · ${address.cidade}/${address.estado}`;
      feedback.textContent = 'Endereço encontrado. Bibliotecas da mesma cidade aparecem primeiro.';
      const groups = [['Mesma cidade', data.mesma_cidade], ['Mesmo estado', data.mesmo_estado], ['Outras regiões', data.outras_regioes]];
      container.replaceChildren();
      let total = 0;
      for (const [title, items] of groups) {
        if (!items.length) continue;
        total += items.length;
        const section = document.createElement('section');
        section.className = 'library-group';
        const heading = document.createElement('h2');
        heading.textContent = title;
        section.appendChild(heading);
        const grid = document.createElement('div');
        grid.className = 'library-grid';
        for (const library of items) {
          const card = document.createElement('article');
          card.className = 'library-card';
          const badge = document.createElement('span');
          badge.className = `badge ${title === 'Mesma cidade' ? 'badge-green' : 'badge-navy'}`;
          badge.textContent = library.badge || `${library.estado} · ${library.cidade}`;
          const name = document.createElement('h3');
          name.textContent = library.nome;
          const location = document.createElement('p');
          location.textContent = `${library.endereco}, ${library.cidade}/${library.estado}`;
          card.append(badge, name, location);
          if (library.cep || library.telefone) {
            const contact = document.createElement('p');
            contact.textContent = [library.cep ? `CEP ${library.cep}` : '', library.telefone].filter(Boolean).join(' · ');
            card.appendChild(contact);
          }
          grid.appendChild(card);
        }
        section.appendChild(grid);
        container.appendChild(section);
      }
      if (!total) {
        const empty = document.createElement('div');
        empty.className = 'empty-state';
        empty.textContent = 'Nenhuma unidade parceira autorizada está cadastrada no sistema no momento.';
        container.appendChild(empty);
      }
    } catch (error) {
      feedback.textContent = error.message || 'Falha na consulta.';
    }
  });
});

