import os
import secrets
from pathlib import Path
from datetime import date

from dotenv import load_dotenv
from sqlalchemy.engine import URL

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")


def _secret_key():
    configured_key = os.environ.get("SECRET_KEY", "").strip()
    if configured_key:
        return configured_key
    key_file = BASE_DIR / "instance" / ".flask_secret_key"
    try:
        key_file.parent.mkdir(parents=True, exist_ok=True)
        if key_file.exists():
            saved_key = key_file.read_text(encoding="utf-8").strip()
            if saved_key:
                return saved_key
        generated_key = secrets.token_hex(32)
        key_file.write_text(generated_key, encoding="utf-8")
        return generated_key
    except OSError:
        return secrets.token_hex(32)


def _database_uri():
    database_url = os.environ.get("DATABASE_URL", "").strip()
    if database_url:
        return database_url
    database_name = os.environ.get("MYSQL_DATABASE", "").strip()
    if database_name:
        return URL.create(drivername="mysql+pymysql", username=os.environ.get("MYSQL_USER", "root"),
                         password=os.environ.get(
                             "MYSQL_PASSWORD",
                             "",
                         ), host=os.environ.get("MYSQL_HOST", "127.0.0.1"),
                         port=int(os.environ.get("MYSQL_PORT", "3306")), database=database_name,
                         query={"charset": "utf8mb4"})
    return f"sqlite:///{BASE_DIR / 'instance' / 'biblioteca.db'}"


def _env_bool(name, default=False):
    value = os.environ.get(name)
    return default if value is None else value.strip().lower() in ("1", "true", "yes", "on")


class Config:
    SECRET_KEY = _secret_key()
    SQLALCHEMY_DATABASE_URI = _database_uri()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {"pool_pre_ping": True}
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = _env_bool("SESSION_COOKIE_SECURE", False)
    MAX_CONTENT_LENGTH = 8 * 1024 * 1024
    TERMS_VERSION = os.environ.get("TERMS_VERSION", "2026-11")
    MP_ACCESS_TOKEN = os.environ.get("MP_ACCESS_TOKEN", "").strip()
    MP_PUBLIC_KEY = os.environ.get("MP_PUBLIC_KEY", "").strip()
    MP_WEBHOOK_SECRET = os.environ.get("MP_WEBHOOK_SECRET", "").strip()
    MP_NOTIFICATION_URL = os.environ.get("MP_NOTIFICATION_URL", "").strip()
    PAYMENT_MODE = os.environ.get("PAYMENT_MODE", "demo").strip().lower()
    if PAYMENT_MODE not in {"demo", "mercadopago", "disabled"}:
        PAYMENT_MODE = "disabled"
    DEMO_PAYMENTS_ENABLED = PAYMENT_MODE == "demo"
    MP_PAYMENTS_ENABLED = PAYMENT_MODE == "mercadopago" and bool(MP_ACCESS_TOKEN and MP_PUBLIC_KEY)
    BUSINESS_CNPJ = os.environ.get("BUSINESS_CNPJ", "CNPJ não informado").strip()
    BUSINESS_ADDRESS = os.environ.get("BUSINESS_ADDRESS", "Endereço não informado").strip()
    BUSINESS_PHONE = os.environ.get("BUSINESS_PHONE", "Telefone não informado").strip()
    BUSINESS_WHATSAPP = "".join(filter(str.isdigit, os.environ.get("BUSINESS_WHATSAPP", "")))
    BUSINESS_EMAIL = os.environ.get("BUSINESS_EMAIL", "").strip()
    CURRENT_YEAR = date.today().year
