# Fontes das capas do acervo

Os JPEGs em `static/images/books/` são capas publicadas encontradas em catálogos editoriais ou lojas de livros. A imagem pode corresponder a uma edição em idioma/formato diferente do registro do catálogo. Direitos pertencem aos respectivos titulares; os links abaixo servem para identificação da origem, não concedem licença de redistribuição. Confirme permissões antes de publicar comercialmente ou substitua por imagens licenciadas pela organização.

| Livro | Arquivo local | Edição/fonte consultada |
|---|---|---|
| Dom Casmurro — Machado de Assis | `dom-casmurro.jpg` | [L&PM](https://www.lpm.com.br/livros/go.asp?id=746264), edição Pocket. |
| 1984 — George Orwell | `1984.jpg` | [Penguin Random House](https://www.penguinrandomhouse.com/books/326569/1984-by-george-orwell-with-a-foreword-by-thomas-pynchon/), edição comemorativa de 75 anos. |
| O Hobbit — J. R. R. Tolkien | `o-hobbit.jpg` | [HarperCollins Brasil](https://harpercollins.com.br/products/o-hobbit-jrr-tolkien). |
| O Alquimista — Paulo Coelho | `o-alquimista.jpg` | [HarperCollins/HarperOne](https://www.harpercollins.com/products/the-alchemist-25th-anniversary-paulo-coelho), edição em inglês The Alchemist, 25th Anniversary. |
| Clean Code — Robert C. Martin | `clean-code.jpg` | [Google Play Books](https://play.google.com/store/books/details/Robert_C_Martin_Clean_Code?id=EpeDEQAAQBAJ), segunda edição. |
| A Revolução dos Bichos — George Orwell | `a-revolucao-dos-bichos.jpg` | [Editora Excelsior](https://www.editoraexcelsior.com.br/a-revolucao-dos-bichos), edição de luxo, ISBN 978-65-87435-24-4. |
| Torto Arado — Itamar Vieira Junior | `torto-arado.jpg` | [Todavia](https://todavialivros.com.br/livros/torto-arado), edição brasileira. |
| Duna — Frank Herbert | `duna.jpg` | [Editora Aleph](https://aleph.com.br/products/duna-1), edição brasileira. |
| Algoritmos: Teoria e Prática — Thomas H. Cormen et al. | `algoritmos-teoria-pratica.jpg` | [Amazon Brasil](https://www.amazon.com.br/Algoritmos-Teoria-Pr%C3%A1tica-Thomas-Cormen/dp/8535236996), 3ª edição em português, GEN LTC, ISBN 978-85-352-3699-6. |
| Orgulho e Preconceito — Jane Austen | `orgulho-e-preconceito.jpg` | [L&PM](https://www.lpm.com.br/livros/go.asp?LivroID=260509&Go=BOOK), edição Pocket. |
| O Sol é para Todos — Harper Lee | `o-sol-e-para-todos.jpg` | [Google Play Books](https://play.google.com/store/books/details/O_sol_%C3%A9_para_todos?id=XVvkCQAAQBAJ&hl=en_US), edição em português. |
| Cien Años de Soledad — Gabriel García Márquez | `cien-anos-de-soledad.jpg` | [Google Play Books](https://play.google.com/store/books/details?id=kmAQCwAAQBAJ), edição limitada da Random House. |
| Capitães da Areia — Jorge Amado | `capitaes-da-areia.jpg` | [Companhia das Letras](https://www.companhiadasletras.com.br/9788535911695-capitaes-da-areia-4241/p), ISBN 978-85-359-1169-5. |
| A Hora da Estrela — Clarice Lispector | `a-hora-da-estrela.jpg` | [Editora Rocco](https://rocco.com.br/produto/a-hora-da-estrela/), edição brasileira. |
| Sapiens — Yuval Noah Harari | `sapiens.jpg` | [Google Play Books](https://play.google.com/store/books/details/Sapiens_A_Brief_History_of_Humankind?id=FmyBAwAAQBAJ&hl=en_US), edição em inglês. |
| O Pequeno Príncipe — Antoine de Saint-Exupéry | `o-pequeno-principe.jpg` | [Editora Maralto](https://maralto.com.br/livros/o-pequeno-principe), edição brasileira. |
