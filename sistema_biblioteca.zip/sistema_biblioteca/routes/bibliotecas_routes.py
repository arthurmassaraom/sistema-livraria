import re
import requests
from flask import Blueprint, render_template, jsonify, abort
from models.biblioteca import Biblioteca

bibliotecas_bp = Blueprint("bibliotecas", __name__)


@bibliotecas_bp.get("/bibliotecas")
def bibliotecas():
    return render_template(
        "bibliotecas.html",
        bibliotecas=Biblioteca.query.order_by(
            Biblioteca.estado,
            Biblioteca.cidade,
            Biblioteca.nome,
        ).all(),
    )


@bibliotecas_bp.get("/api/cep/<cep>")
def consulta_cep(cep):
    cep_limpo = re.sub(r"\D", "", cep)
    if len(cep_limpo) != 8:
        return jsonify({"erro": "Informe um CEP válido com 8 números."}), 400
    try:
        response = requests.get(f"https://viacep.com.br/ws/{cep_limpo}/json/", timeout=6)
        response.raise_for_status()
        data = response.json()
    except requests.RequestException:
        return jsonify({"erro": "Não foi possível consultar o ViaCEP agora."}), 502
    if data.get("erro"):
        return jsonify({"erro": "CEP não encontrado."}), 404

    cidade, uf = (data.get("localidade") or "").casefold(), (data.get("uf") or "").upper()
    locais = Biblioteca.query.order_by(Biblioteca.nome).all()
    same_city = [b for b in locais if b.estado.upper() == uf and b.cidade.casefold() == cidade]
    same_state = [b for b in locais if b.estado.upper() == uf and b not in same_city]
    other = [b for b in locais if b.estado.upper() != uf]

    def dump(b, badge=None):
        return {"nome": b.nome, "cep": b.cep, "endereco": b.endereco,
                "cidade": b.cidade, "estado": b.estado, "telefone": b.telefone, "badge": badge}

    nearby = [dump(b, "Mais próxima da sua cidade") for b in same_city]
    within_state = [dump(b, "Mesmo estado") for b in same_state]
    others = [dump(b, "Outra região") for b in other]
    return jsonify({
        "endereco": {"cep": data.get("cep"), "logradouro": data.get("logradouro"),
                     "bairro": data.get("bairro"), "cidade": data.get("localidade"), "estado": uf},
        "mesma_cidade": nearby,
        "mesmo_estado": within_state,
        "outras_regioes": others,
    })
