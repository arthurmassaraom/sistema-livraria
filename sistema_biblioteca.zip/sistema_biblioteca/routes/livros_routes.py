from datetime import date
from flask import Blueprint, abort, flash, redirect, render_template, request, session, url_for
from sqlalchemy import or_
from database import db
from models.avaliacao import Avaliacao
from models.livro import Livro
from models.transacao import Transacao
from services.avaliacoes import anexar_estatisticas_avaliacoes

livros_bp = Blueprint("livros", __name__)


@livros_bp.get("/livros")
def catalogo():
    q = request.args.get("q", "").strip()
    genero = request.args.get("genero", "").strip()
    categoria = request.args.get("categoria", "").strip()
    modalidade = request.args.get("modalidade", "").strip()
    query = Livro.query.filter_by(ativo=True).filter(Livro.estoque > 0)
    if q:
        termo = f"%{q}%"
        query = query.filter(or_(
            Livro.titulo.ilike(termo),
            Livro.autor.ilike(termo),
            Livro.isbn.ilike(termo),
        ))
    if genero:
        query = query.filter_by(genero=genero)
    if categoria:
        query = query.filter_by(categoria=categoria)
    if modalidade in ("Venda", "Aluguel"):
        query = query.filter(Livro.modalidade.in_([modalidade, "Ambos"]))
    livros = anexar_estatisticas_avaliacoes(query.order_by(Livro.titulo).all())
    generos = [r[0] for r in db.session.query(Livro.genero).filter_by(ativo=True).distinct().order_by(Livro.genero).all()]
    categorias = [r[0] for r in db.session.query(Livro.categoria).filter_by(ativo=True).distinct().order_by(Livro.categoria).all()]
    return render_template("livros.html", livros=livros, q=q, genero=genero, categoria=categoria,
                           modalidade=modalidade, generos=generos, categorias=categorias)


@livros_bp.get("/livros/<int:livro_id>")
def detalhes(livro_id):
    livro = db.session.get(Livro, livro_id)
    if not livro or not livro.ativo:
        abort(404)
    anexar_estatisticas_avaliacoes([livro])
    avaliacoes = (Avaliacao.query.filter_by(livro_id=livro.id)
                  .order_by(Avaliacao.criada_em.desc()).all())
    usuario_id = session.get("usuario_id")
    ja_comprou = bool(usuario_id and Transacao.query.filter_by(
        usuario_id=usuario_id, livro_id=livro.id, pagamento_status="approved"
    ).filter(Transacao.status.in_(["ativa", "concluida", "devolvida"])).first())
    minha_avaliacao = Avaliacao.query.filter_by(
        livro_id=livro.id,
        usuario_id=usuario_id,
    ).first() if usuario_id else None
    return render_template("livro_detalhe.html", livro=livro, avaliacoes=avaliacoes,
                           pode_avaliar=ja_comprou, minha_avaliacao=minha_avaliacao)


@livros_bp.post("/livros/<int:livro_id>/avaliacoes")
def avaliar(livro_id):
    usuario_id = session.get("usuario_id")
    if not usuario_id:
        flash("Entre na sua conta para avaliar esta obra.", "erro")
        return redirect(url_for(
            "usuarios.login",
            next=url_for("livros.detalhes", livro_id=livro_id),
        ))
    livro = db.session.get(Livro, livro_id)
    if not livro or not livro.ativo:
        abort(404)
    elegivel = Transacao.query.filter_by(usuario_id=usuario_id, livro_id=livro.id,
                                        pagamento_status="approved").filter(
        Transacao.status.in_(["ativa", "concluida", "devolvida"])).first()
    if not elegivel:
        flash("A avaliação fica disponível após uma compra ou aluguel pago desta obra.", "erro")
        return redirect(url_for("livros.detalhes", livro_id=livro_id))
    try:
        estrelas = int(request.form.get("estrelas", "0"))
    except (ValueError, TypeError):
        estrelas = 0
    comentario = request.form.get("comentario", "").strip()
    if estrelas not in range(1, 6) or not comentario or len(comentario) > 1500:
        flash("Escolha de 1 a 5 estrelas e escreva um comentário de até 1.500 caracteres.", "erro")
        return redirect(url_for("livros.detalhes", livro_id=livro_id))
    review = Avaliacao.query.filter_by(livro_id=livro.id, usuario_id=usuario_id).first()
    if review:
        review.estrelas, review.comentario = estrelas, comentario
    else:
        db.session.add(Avaliacao(livro_id=livro.id, usuario_id=usuario_id,
                                 estrelas=estrelas, comentario=comentario))
    db.session.commit()
    return redirect(url_for("livros.detalhes", livro_id=livro_id) + "#avaliacoes")


@livros_bp.post("/livros/transacoes/<int:transacao_id>/devolver")
def devolver(transacao_id):
    usuario_id = session.get("usuario_id")
    if not usuario_id:
        return redirect(url_for("usuarios.login", next=url_for("usuarios.perfil")))
    tx = db.session.get(Transacao, transacao_id)
    if not tx or tx.usuario_id != usuario_id or tx.tipo != "aluguel" or tx.status != "ativa" or tx.pagamento_status != "approved":
        flash("Aluguel não encontrado ou indisponível para devolução.", "erro")
        return redirect(url_for("usuarios.perfil"))
    tx.data_devolucao = date.today()
    tx.multa = tx.calcular_multa()
    tx.status = "devolvida"
    tx.livro.estoque += tx.quantidade or 1
    tx.estoque_debitado = False
    db.session.commit()
    return redirect(url_for("usuarios.perfil"))
