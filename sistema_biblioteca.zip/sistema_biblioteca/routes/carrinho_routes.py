from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from database import db
from models.livro import Livro
from models.usuario import Usuario
from models.biblioteca import Biblioteca

carrinho_bp = Blueprint("carrinho", __name__)
FRETE_FIXO = 12.90


def _cart():
    return session.setdefault("carrinho", {})


def _item_key(book_id, tipo, dias):
    return f"{int(book_id)}:{tipo}:{int(dias)}"


def _parse_key(key):
    book_id, tipo, dias = key.split(":", 2)
    return int(book_id), tipo, int(dias)


def _cart_rows():
    rows, total = [], 0.0
    cart = _cart()
    for key, raw_qty in list(cart.items()):
        try:
            book_id, tipo, dias = _parse_key(key)
            qty = max(1, int(raw_qty))
        except (ValueError, TypeError):
            cart.pop(key, None)
            continue
        book = db.session.get(Livro, book_id)
        if not book or not book.ativo:
            cart.pop(key, None)
            continue
        if tipo not in ("aluguel", "compra"):
            cart.pop(key, None)
            continue
        unit = book.preco_aluguel if tipo == "aluguel" else book.preco_venda
        subtotal = round(unit * qty, 2)
        total += subtotal
        rows.append({"key": key, "livro": book, "tipo": tipo, "dias": dias, "quantidade": qty,
                     "unitario": unit, "subtotal": subtotal})
    return rows, round(total, 2)


@carrinho_bp.get("/carrinho")
def ver_carrinho():
    rows, subtotal = _cart_rows()
    entrega = request.args.get("entrega", "domicilio")
    frete = FRETE_FIXO if entrega == "domicilio" and rows else 0
    return render_template(
        "carrinho.html",
        rows=rows,
        subtotal=subtotal,
        frete=frete,
        total=round(subtotal + frete, 2),
    )


@carrinho_bp.post("/carrinho/adicionar")
def adicionar():
    try:
        book_id = int(request.form.get("livro_id", ""))
        tipo = request.form.get("tipo", "aluguel")
        dias = int(request.form.get("dias", "14")) if tipo == "aluguel" else 0
        qty = int(request.form.get("quantidade", "1"))
    except (ValueError, TypeError):
        flash("Os dados do item não são válidos.", "erro")
        return redirect(url_for("livros.catalogo"))
    book = db.session.get(Livro, book_id)
    if not book or not book.ativo or book.estoque <= 0:
        flash("Livro indisponível no momento.", "erro")
        return redirect(url_for("livros.catalogo"))
    if tipo not in ("aluguel", "compra") or qty < 1 or qty > 20:
        flash("Selecione uma quantidade válida.", "erro")
        return redirect(url_for("livros.catalogo"))
    if tipo == "aluguel" and (dias not in (
        7,
        14,
        30,
    ) or book.modalidade not in ("Aluguel", "Ambos")):
        flash("Modalidade ou período de aluguel inválido.", "erro")
        return redirect(url_for("livros.catalogo"))
    if tipo == "compra" and book.modalidade not in ("Venda", "Ambos"):
        flash("Este livro não está disponível para compra.", "erro")
        return redirect(url_for("livros.catalogo"))
    key = _item_key(book_id, tipo, dias)
    cart = dict(_cart())
    cart[key] = min(int(cart.get(key, 0)) + qty, book.estoque)
    session["carrinho"] = cart
    session.pop("checkout_reference", None)
    return redirect(request.referrer or url_for("carrinho.ver_carrinho"))


@carrinho_bp.post("/carrinho/atualizar")
def atualizar():
    key = request.form.get("key", "")
    cart = dict(_cart())
    if key not in cart:
        flash("Item não encontrado no carrinho.", "erro")
        return redirect(url_for("carrinho.ver_carrinho"))
    try:
        qty = int(request.form.get("quantidade", "0"))
        book_id, _, _ = _parse_key(key)
        book = db.session.get(Livro, book_id)
        if qty <= 0:
            cart.pop(key, None)
        elif not book or qty > book.estoque:
            flash("A quantidade solicitada supera o estoque disponível.", "erro")
        else:
            cart[key] = min(qty, 20)
    except (ValueError, TypeError):
        flash("Quantidade inválida.", "erro")
    session["carrinho"] = cart
    session.pop("checkout_reference", None)
    return redirect(url_for("carrinho.ver_carrinho"))


@carrinho_bp.post("/carrinho/remover")
def remover():
    cart = dict(_cart())
    cart.pop(request.form.get("key", ""), None)
    session["carrinho"] = cart
    session.pop("checkout_reference", None)
    return redirect(url_for("carrinho.ver_carrinho"))


@carrinho_bp.get("/checkout")
def checkout():
    user_id = session.get("usuario_id")
    if not user_id:
        flash("Entre na sua conta antes de finalizar o pedido.", "erro")
        return redirect(url_for("usuarios.login", next=url_for("carrinho.checkout")))
    user = db.session.get(Usuario, user_id)
    if not user or user.is_admin:
        return redirect(url_for("admin.dashboard"))
    rows, subtotal = _cart_rows()
    if not rows:
        flash("Seu carrinho está vazio.", "erro")
        return redirect(url_for("carrinho.ver_carrinho"))
    return render_template("checkout.html", rows=rows, subtotal=subtotal, user=user,
                           bibliotecas=Biblioteca.query.order_by(
                               Biblioteca.estado,
                               Biblioteca.cidade,
                               Biblioteca.nome,
                           ).all(),
                           frete=FRETE_FIXO)
