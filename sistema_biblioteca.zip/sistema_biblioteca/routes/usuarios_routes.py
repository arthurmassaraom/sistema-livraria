import re
from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from database import db
from models.usuario import Usuario
from models.plano import Plano
from models.transacao import Transacao

usuarios_bp = Blueprint("usuarios", __name__)


@usuarios_bp.route("/login", methods=["GET", "POST"])
def login():
    login_error = None
    login_email = ""
    if request.method == "POST":
        acao = request.form.get("acao", "login")
        email = request.form.get("email", "").strip().casefold()
        login_email = email
        senha = request.form.get("senha", "")
        if acao == "cadastro":
            nome = request.form.get("nome", "").strip()
            if len(nome.split()) < 2 or len(nome) > 120 or not 8 <= len(senha) <= 128:
                flash("Informe nome e sobrenome e uma senha entre 8 e 128 caracteres.", "erro")
            elif len(email) > 160 or not re.fullmatch(
                r"[^@\s]+@[^@\s]+\.[^@\s]+",
                email,
            ) or Usuario.query.filter(db.func.lower(Usuario.email) == email).first():
                flash("Não foi possível criar a conta com os dados informados.", "erro")
            else:
                usuario = Usuario(nome=nome, email=email)
                usuario.set_senha(senha)
                db.session.add(usuario)
                db.session.commit()
                session.clear()
                session["usuario_id"] = usuario.id
                return redirect(url_for("usuarios.perfil"))
        else:
            # Também permite entrar em contas antigas cujo e-mail foi salvo com letras maiúsculas.
            usuario = Usuario.query.filter(db.func.lower(Usuario.email) == email).first()
            if usuario and usuario.verificar_senha(senha):
                session.clear()
                session["usuario_id"] = usuario.id
                if usuario.is_admin:
                    return redirect(url_for("admin.dashboard"))
                destino = request.args.get("next") or url_for("usuarios.perfil")
                if not destino.startswith("/") or destino.startswith("//"):
                    destino = url_for("usuarios.perfil")
                return redirect(destino)
            login_error = "E-mail ou senha inválidos."
    return render_template("login.html", login_error=login_error, login_email=login_email)


@usuarios_bp.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("main.home"))


@usuarios_bp.get("/perfil")
def perfil():
    if not session.get("usuario_id"):
        flash("Entre na sua conta para acessar o perfil.", "erro")
        return redirect(url_for("usuarios.login", next=url_for("usuarios.perfil")))
    usuario = db.session.get(Usuario, session["usuario_id"])
    transacoes = Transacao.query.filter_by(usuario_id=usuario.id).order_by(Transacao.data_transacao.desc()).all()
    multas = sum(tx.multa if tx.status != "ativa" else tx.calcular_multa()
                 for tx in transacoes if tx.tipo == "aluguel")
    return render_template("perfil.html", usuario=usuario, transacoes=transacoes, multas=multas)


@usuarios_bp.post("/planos/<int:plano_id>/contratar")
def contratar(plano_id):
    if not session.get("usuario_id"):
        return redirect(url_for("usuarios.login"))
    usuario = db.session.get(Usuario, session["usuario_id"])
    if usuario.is_admin:
        return redirect(url_for("admin.dashboard"))
    plano = db.session.get(Plano, plano_id)
    if not plano:
        flash("Plano não encontrado.", "erro")
    else:
        usuario.plano_id = plano.id
        db.session.commit()
    return redirect(url_for("main.planos"))
