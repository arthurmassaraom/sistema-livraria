from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from models.biblioteca import Biblioteca
from models.doacao import Doacao
from database import db

doacoes_bp = Blueprint("doacoes", __name__)

@doacoes_bp.route("/doe", methods=["GET", "POST"])
def doe():
    if not session.get("usuario_id"):
        flash("Entre na sua conta para registrar uma doação.", "erro")
        return redirect(url_for("usuarios.login", next=url_for("doacoes.doe")))
    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        autor = request.form.get("autor", "").strip()
        entrega = request.form.get("biblioteca_entrega", "").strip()
        ano_raw = request.form.get("ano", "").strip()
        if not titulo or not autor or not entrega:
            flash("Preencha título, autor e biblioteca de entrega.", "erro")
        else:
            try:
                ano = int(ano_raw) if ano_raw else None
                doacao = Doacao(titulo=titulo, autor=autor, editora=request.form.get(
                    "editora",
                    "",
                ).strip(), ano=ano,
                    isbn=request.form.get(
                        "isbn",
                        "",
                    ).strip() or None, conservacao=request.form.get("conservacao", "Boa"),
                    biblioteca_entrega=entrega, usuario_id=session["usuario_id"])
                db.session.add(doacao)
                db.session.commit()
                flash("Doação enviada para análise da equipe.", "sucesso")
                return redirect(url_for("doacoes.doe"))
            except ValueError:
                db.session.rollback()
                flash("O ano informado precisa ser numérico.", "erro")
    minhas = Doacao.query.filter_by(usuario_id=session["usuario_id"]).order_by(Doacao.criada_em.desc()).all()
    bibliotecas = Biblioteca.query.order_by(Biblioteca.nome).all()
    return render_template("doe.html", minhas=minhas, bibliotecas=bibliotecas)
