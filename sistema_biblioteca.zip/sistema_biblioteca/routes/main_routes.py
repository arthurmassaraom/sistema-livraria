from flask import Blueprint, render_template
from sqlalchemy import func, and_
from models.livro import Livro
from models.plano import Plano
from models.transacao import Transacao
from services.avaliacoes import anexar_estatisticas_avaliacoes

main_bp = Blueprint("main", __name__)


@main_bp.get("/")
def home():
    popular = (Livro.query.outerjoin(
        Transacao, and_(Transacao.livro_id == Livro.id, Transacao.pagamento_status == "approved")
    ).filter(Livro.ativo.is_(True), Livro.estoque > 0)
       .group_by(Livro.id).order_by(func.count(Transacao.id).desc(), Livro.titulo)
       .limit(9).all())
    hero = popular[0] if popular else Livro.query.filter_by(ativo=True).first()
    activity = Transacao.query.filter_by(
        livro_id=hero.id,
        pagamento_status="approved",
    ).count() if hero else 0
    alugados = (Livro.query.filter_by(ativo=True).filter(Livro.estoque > 0)
                .order_by(Livro.titulo).limit(8).all())
    anexar_estatisticas_avaliacoes(([hero] if hero else []) + popular + alugados)
    return render_template(
        "home.html",
        hero=hero,
        atividade=activity,
        destaques=popular[1:5],
        alugados=alugados,
    )


@main_bp.get("/planos")
def planos():
    return render_template("planos.html", planos=Plano.query.order_by(Plano.preco_mensal).all())


@main_bp.get("/termos")
def termos():
    return render_template("termos.html")
