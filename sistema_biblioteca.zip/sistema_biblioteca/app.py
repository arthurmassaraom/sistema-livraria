from pathlib import Path
import secrets
import hmac
from datetime import date

from flask import Flask, abort, redirect, request, session, url_for
from config import Config
from database import db
from routes import register_blueprints
from seed import seed_database
from create_admin import create_admin, promote_admin
from services.sqlite_migrations import upgrade_legacy_sqlite


def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(Config)
    if test_config:
        app.config.update(test_config)
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    db.init_app(app)
    register_blueprints(app)
    app.cli.add_command(create_admin)
    app.cli.add_command(promote_admin)

    def csrf_token():
        token = session.get("_csrf_token")
        if not token:
            token = secrets.token_urlsafe(32)
            session["_csrf_token"] = token
        return token

    app.jinja_env.globals["csrf_token"] = csrf_token

    @app.before_request
    def security_and_admin_boundary():
        is_payment_webhook = request.endpoint == "pagamentos.webhook"
        if request.method == "POST" and not app.testing and not is_payment_webhook:
            expected = session.get("_csrf_token", "")
            supplied = request.form.get(
                "_csrf_token",
                "",
            ) or request.headers.get("X-CSRF-Token", "")
            if not expected or not supplied or not hmac.compare_digest(expected, supplied):
                abort(
                    400,
                    description="A sessão do formulário expirou. Atualize a página e tente novamente.",
                )
        user_id = session.get("usuario_id")
        if user_id and request.endpoint not in (
            None,
            "static",
            "usuarios.logout",
            "pagamentos.webhook",
        ):
            from models.usuario import Usuario
            user = db.session.get(Usuario, user_id)
            if user and user.is_admin and not request.endpoint.startswith("admin."):
                return redirect(url_for("admin.dashboard"))
        return None

    @app.after_request
    def security_headers(response):
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        response.headers.setdefault(
            "Permissions-Policy",
            "camera=(), microphone=(), geolocation=()",
        )
        if request.endpoint != "static":
            response.headers["Cache-Control"] = "private, no-store, max-age=0"
            response.headers["Pragma"] = "no-cache"
            response.headers["Vary"] = "Cookie"
        if app.config.get("SESSION_COOKIE_SECURE"):
            response.headers.setdefault(
                "Strict-Transport-Security",
                "max-age=31536000; includeSubDomains",
            )
        return response

    @app.context_processor
    def inject_context():
        from models.usuario import Usuario
        usuario = db.session.get(
            Usuario,
            session.get("usuario_id"),
        ) if session.get("usuario_id") else None
        return {"usuario_atual": usuario, "pagamentos_habilitados": app.config.get(
            "MP_PAYMENTS_ENABLED",
            False,
        ),
                "modo_demo": app.config.get("DEMO_PAYMENTS_ENABLED", False),
                "versao_termos": app.config.get("TERMS_VERSION", "2026-11"),
                "current_year": date.today().year}

    with app.app_context():
        from models import Usuario, Livro, Plano, Doacao, Biblioteca, Transacao, Avaliacao  # noqa: F401
        db.create_all()
        upgrade_legacy_sqlite()
        seed_database()
    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=app.config.get("DEBUG", False))
