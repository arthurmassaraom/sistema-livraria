from database import db


class Biblioteca(db.Model):
    __tablename__ = "bibliotecas"
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(160), nullable=False)
    cep = db.Column(db.String(12), nullable=False, index=True)
    endereco = db.Column(db.String(200), nullable=False)
    cidade = db.Column(db.String(100), nullable=False)
    estado = db.Column(db.String(2), nullable=False)
    telefone = db.Column(db.String(30), default="")
    transacoes = db.relationship("Transacao", back_populates="biblioteca", lazy=True)
